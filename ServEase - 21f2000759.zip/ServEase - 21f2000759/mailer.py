from flask_mail import Mail

mailer = Mail()