<template>
  <div id="app">
    <nav>
      <!-- Logo Section -->
      <div class="logo">
        <router-link to="/">ServEase</router-link>
      </div>

      <!-- Links for all users -->
      <div class="links">
        <router-link to="/about">About</router-link>

        <!-- Links for logged-in users -->
        <template v-if="isLoggedIn">
          <router-link v-if="role === 'admin'" to="/dashboard">Admin Dashboard</router-link>
          <router-link v-if="role === 'service_professional'" to="/professional-dashboard">Professional Dashboard</router-link>
          <router-link v-if="role === 'customer'" to="/customerDashboard">Customer Dashboard</router-link>
          <a @click="logout">Logout</a>
        </template>

        <!-- Links for non-logged-in users -->
        <template v-else>
          <router-link to="/login">Login</router-link>
        </template>
      </div>
    </nav>

    <router-view />
  </div>
</template>

<script>
export default {
  data() {
    return {
      role: null, // User role (e.g., admin, service_professional, customer)
      token: null, // Auth token
    };
  },
  computed: {
    isLoggedIn() {
      return !!this.token; // Check if the user is logged in
    },
  },
  created() {
    // Load role and token from localStorage
    this.role = localStorage.getItem("role");
    this.token = localStorage.getItem("authToken");
  },
  methods: {
    logout() {
      // Clear the token and role on logout
      localStorage.clear();
      alert("You have been logged out");
      this.role = null;
      this.token = null;
      this.$router.push("/login");
    },
  },
};
</script>

<style scoped>
/* Overall App Styling */
#app {
  font-family: 'Roboto', Arial, sans-serif;
  color: #333;
  text-align: center;
}

/* Navbar Styling */
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 20px;
  background: linear-gradient(90deg, #007bff, #6c63ff);
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  margin: 15px auto;
  max-width: 90%;
  color: white;
}

/* Logo Section */
nav .logo {
  font-size: 24px;
  font-weight: bold;
}

nav .logo a {
  color: white;
  text-decoration: none;
}

/* Navigation Links */
nav .links {
  display: flex;
  align-items: center;
}

nav .links a {
  font-size: 16px;
  font-weight: 500;
  color: white;
  text-decoration: none;
  margin: 0 10px;
  padding: 8px 15px;
  border-radius: 4px;
  transition: background-color 0.3s, transform 0.3s;
}

nav .links a.router-link-exact-active {
  background-color: rgba(255, 255, 255, 0.3);
  color: #fff;
}

nav .links a:hover {
  background-color: rgba(255, 255, 255, 0.4);
  transform: scale(1.1);
}

/* Logout Link Styling */
nav .links a:last-child {
  color: #ffdddd;
  font-weight: bold;
}

nav .links a:last-child:hover {
  color: #ff9b9b;
  background-color: rgba(255, 0, 0, 0.2);
}

/* Mobile Responsiveness */
@media (max-width: 768px) {
  nav {
    flex-direction: column;
    align-items: flex-start;
    padding: 10px;
  }

  nav .links {
    flex-wrap: wrap;
    margin-top: 10px;
  }

  nav .links a {
    margin: 5px 0;
  }
}
</style>
