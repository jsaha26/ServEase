<template>
    <div class="create-category-container">
      <h3>Create Category</h3>
      <!-- Input for Category Name -->
       <div class="form-group">
        <label for="name">Category Name:</label>
        <input 
          type="text" 
          placeholder="Category Name" 
          v-model="name" 
          required 
        />
      </div>
      
      <!-- Input for Category Description -->
      <div class="form-group">
        <label for="desc">Description:</label>
        <input 
          type="text" 
          placeholder="Description" 
          v-model="desc" 
        />
      </div>

      
    <!-- Submit Button -->
    <button @click="submit" class="submit-btn">Submit</button>
  </div>
</template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'createCategory',
    data() {
      return {
        name: '',          // Category name
        desc: '',          // Category description
        token: null,       // Authentication token
        role: null         // User role (to ensure admin access)
      };
    },
    
    created() {
      // Retrieve the token and role from localStorage
      this.token = localStorage.getItem('authToken');
      this.role = localStorage.getItem('role');
      
      // Redirect if the token or role is not valid
      if (!this.token) {
        this.$router.push({ name: 'login' });
      } else if (this.role !== 'admin') {
        // Clear localStorage if the user is not an admin
        localStorage.clear();
        this.$router.push({ name: 'login' });
      }
    },
    
    methods: {
      submit() {
        if (!this.name || !this.desc) {
          alert("Please fill in both fields.");
          return;
        }
  
        // Sending a POST request to create the category
        axios.post('http://localhost:5000/add_category', 
          {
            name: this.name,        // Category name
            description: this.desc  // Category description
          },
          {
            headers: {
              'Authorization': this.token  // Authorization header
            }
          }
        )
        .then(response => {
          // Handle success
          console.log("Category created successfully", response);
          alert("Category created successfully!");
          this.$emit('close')
          this.$router.push('/dashboard');  // For example, redirect to the category list
        })
        .catch(error => {
          // Handle error
          console.error("Error creating category", error);
        });
      }
    }
  };
  </script>
  
<style scoped>
/* Container Styling */
.create-category-container {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
}

/* Heading Styling */
h3 {
  font-size: 1.5rem;
  margin-bottom: 20px;
  color: #333;
}

/* Form Group Styling */
.form-group {
  margin-bottom: 15px;
  text-align: left;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  font-size: 0.9rem;
  color: #555;
}

input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 0.9rem;
  box-sizing: border-box;
  transition: border-color 0.3s ease;
}

input:focus {
  border-color: #4caf50;
  outline: none;
  box-shadow: 0 0 4px rgba(76, 175, 80, 0.3);
}

/* Button Styling */
button.submit-btn {
  width: 100%;
  padding: 10px 15px;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

button.submit-btn:hover {
  background-color: #45a049;
}

button:active {
  background-color: #3e8e41;
}

/* Responsive Styling */
@media (max-width: 480px) {
  .create-category-container {
    padding: 15px;
  }

  h3 {
    font-size: 1.3rem;
  }

  input {
    font-size: 0.85rem;
  }

  button.submit-btn {
    font-size: 0.9rem;
  }
}
</style>