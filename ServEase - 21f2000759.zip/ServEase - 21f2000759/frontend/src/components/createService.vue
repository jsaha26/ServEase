<template>
    <div class="create-service">
      <h2>Add New Service</h2>
      <form @submit.prevent="submitService">
        <label for="name">Service Name:</label>
        <input type="text" v-model="name" required />
  
        <label for="price">Price:</label>
        <input type="number" v-model="price" required />
  
        <label for="description">Description:</label>
        <input type="text" v-model="description" required />
  
        <button type="submit">Add Service</button>
      </form>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    name: 'CreateService',
    props: ['category_id'],
    data() {
      return {
        name: '',
        price: '',
        description: '',
        token: null,
      };
    },
    created() {
      this.token = localStorage.getItem('authToken');
      if (!this.token) {
        this.$router.push('/login');
      }
    },
    methods: {
      async submitService() {
        try {
          const response = await axios.post(
            'http://127.0.0.1:5000/services',
            {
              name: this.name,
              price: this.price,
              description: this.description,
              category_id: this.category_id,
            },
            {
              headers: {
                Authorization: this.token, // Authorization header
              },
            }
          );
          alert('Service added successfully!');
          this.$router.push({ name: 'dashboard' });
        } catch (error) {
          console.error('Error adding service:', error);
        }
      },
    },
  };
  </script>
  
  <style scoped>
  /* Add styles as needed */
  </style>
  