<template>
  <div class="dashboard">

    <!-- Button to toggle the navbar visibility -->
    <button class="toggle-navbar-btn" @click="toggleNavbar">
      Toggle Navbar
    </button>

    <div v-if="isNavbarVisible" class="floating-navbar">
      <ul>
        <ul><a href="#" @click="scrollToSection('profile')">Profile</a></ul>
        <ul><a href="#" @click="scrollToSection('categories')">Categories</a></ul>
        <ul><a href="#" @click="scrollToSection('search')">Search Services</a></ul>
        <ul><a href="#" @click="scrollToSection('history')">Service History</a></ul>
        <ul><a href="#" @click="scrollToSection('summary')">Dashboard Summary</a></ul>
      </ul>
    </div>


    
    <header class="dashboard-header">
      <h1>Customer's Dashboard</h1>
      <h2>Welcome, {{ customer.name }}</h2>
    </header>


    <section id="profile" class="profile-card">
      <h2>Profile</h2>
      <ul class="profile-details">
        <ul>
          <strong><label for="name">Name:</label></strong>
          <span>{{ customer.name }}</span>
        </ul>
        <ul>
          <strong><label for="email">Email:</label></strong>
          <span>{{ customer.email }}</span>
        </ul>
        <ul>
          <strong><label for="phone">Phone Number:</label></strong>
          <span>{{ customer.phone_number }}</span>
        </ul>
        <ul>
          <strong><label for="address">Address:</label></strong>
          <span>{{ customer.address }}</span>
        </ul>
      </ul>
      <button class="btn btn-primary" @click="editProfile">Edit Profile</button>
    </section>

    <!-- Section for Categories -->
    <section id="categories" class="categories-card">
      <h2>Looking For?</h2>
      <div class="category-list">
        <button class="btn btn-category" v-for="category in categories" :key="category.id"
          @click="showCategoryServices(category.id)">
          {{ category.name }}
        </button>
      </div>
    </section>

    <section id="search" class="search-section card">
      <h2>Search for Services</h2>
      <div class="search-wrapper">
        <input type="text" v-model="searchText" placeholder="Search by service name, or category" />
        <button class="btn btn-primary" @click="searchServices">Search</button>
      </div>
      <div v-if="searchResults.length > 0" class="search-results">
        <h3>Search Results</h3>
        <ul>
          <ul v-for="service in searchResults" :key="service.id">
            <div class="service-item">
              <h4>{{ service.name }}</h4>
              <span class="service-description">{{ service.description }}</span>
              <span class="service-price">₹{{ service.price }}</span>
            </div>
            <button class="btn btn-success" @click="bookService(service)">Book Now</button>

          </ul>
        </ul>
      </div>
    </section>

    <section id="history" class="service-history card">
      <h2>Service History</h2>
      <div v-if="serviceHistory.length > 0">
        <table class="service-table">
          <thead>
            <tr>
              <th>Service ID</th>
              <th>Service Name</th>
              <th>Professional Name</th>
              <th>Phone Number</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <!-- Loop through service history and display each service -->
            <tr v-for="service in serviceHistory" :key="service.id">
              <td>{{ service.service_id }}</td>
              <td>{{ service.service_name }}</td>
              <td>{{ service.professional_name }} (Rating: {{ service.professional_average_rating || 'N/A' }})</td>
              <td>{{ service.professional_phone }}</td>
              <td>{{ service.status }}</td>
              <td>
                <button v-if="service.status === 'Pending'" class="btn btn-danger"
                  @click="cancelService(service)">Cancel</button>
                <button v-if="service.status === 'Completed'" class="btn btn-primary"
                  @click="rateService(service)">Rate</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else>
        <p>No service history found.</p>
      </div>
    </section>


    <div v-if="showRatingModal" class="rating-modal">
      <h3>Rate Professional</h3>
      <form @submit.prevent="submitRating">
        <label for="rating">Rating (1-5):</label>
        <input type="number" v-model="rating" min="1" max="5" required />

        <label for="review_text">Review:</label>
        <textarea v-model="reviewText" required></textarea>

        <button type="submit">Submit</button>
        <button type="button" @click="closeRatingModal">Cancel</button>
      </form>
    </div>



    <!-- Summary Charts Section -->
    <section id="summary" class="dashboard-summary card">
      <h2>Dashboard Summary</h2>
      <div class="charts-container">
        <canvas id="serviceStatusChart"></canvas>
        <!-- <canvas id="serviceHistoryChart"></canvas> -->
      </div>
    </section>


    <div v-if="showEditModal" class="modal">
      <div class="modal-content">
        <h2>Edit Profile</h2>
        <form @submit.prevent="submitProfileEdit">
          <label for="name">Name:</label>
          <input v-model="editableCustomer.name" type="text" required />

          <label for="email">Email:</label>
          <input v-model="editableCustomer.email" type="email" required />

          <label for="phone">Phone Number:</label>
          <input v-model="editableCustomer.phone_number" type="text" required />

          <label for="address">Address:</label>
          <input v-model="editableCustomer.address" type="text" required />

          <div class="modal-actions">
            <button class="btn btn-primary" type="submit">Save</button>
            <button class="btn btn-secondary" type="button" @click="closeEditModal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>

</template>

<script>
import axios from 'axios';
import Chart from 'chart.js/auto';
export default {
  data() {
    return {
      customer: {},
      searchText: '',
      categories: [],
      searchResults: [],
      serviceHistory: [],
      showRatingModal: false,
      rating: null,
      reviewText: '',
      currentService: null, // To hold the service being rated
      selectedCategory: null, // To hold the selected category
      token: null,
      serviceStatusData: null,
      serviceHistoryData: null,
      serviceStatusChart: null,
      // serviceHistoryChart: null,
      editableCustomer: {},
      showEditModal: false,
      isNavbarVisible: true,
    };
  },
  watch: {
    serviceHistory: {
      immediate: true,
      handler() {
        if (this.serviceHistory.length > 0) {
          this.prepareChartData();
        }
      },
    },
  },
  created() {

    this.token = localStorage.getItem('authToken');
    this.role = localStorage.getItem('role');
    if (!this.token || this.role !== 'customer') {
      this.$router.push('/login');
    }


    // Fetch customer data from your backend API
    this.fetchCustomerData();
    // Fetch service history from your backend API
    this.fetchServiceHistory();
    this.fetchCategories();
  },
  mounted() {
    this.prepareChartData();
  },
  methods: {

    toggleNavbar() {
      this.isNavbarVisible = !this.isNavbarVisible;
    },
    scrollToSection(sectionId) {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    },
    fetchCustomerData() {
      axios.get('http://127.0.0.1:5000/customer/profile', { headers: { 'Authorization': this.token } })
        .then(response => {
          this.customer = response.data;

          if (this.customer.active === false) {
            alert('Your account is inactive/blocked. Please contact support.');
            this.$router.push('/login');
          }
        })
        .catch(error => {
          console.error('Error fetching customer data:', error);
          // Handle errors, e.g., show an error message to the user

        });
    },
    fetchCategories() {
      axios.get('http://127.0.0.1:5000/all_categories', { headers: { 'Authorization': this.token } })
        .then(response => {
          this.categories = response.data;
        })
        .catch(error => {
          console.error('Error fetching categories:', error);
        });
    },
    showCategoryServices(categoryId) {
      this.selectedCategoryId = categoryId;
      axios.get(`http://127.0.0.1:5000/services/category/${categoryId}`, { headers: { 'Authorization': this.token } })
        .then(response => {
          this.searchResults = response.data; // Populate search results with category services
        })
        .catch(error => {
          console.error('Error fetching services for category:', error);
        });
    },

    fetchServiceHistory() {
      axios
        .get('http://127.0.0.1:5000/service_requests', { headers: { Authorization: this.token } })
        .then(async (response) => {
          // Fetch additional details for each service, such as professional name and service name
          const servicesWithDetails = await Promise.all(
            response.data.map(async (service) => {
              const [rating, serviceDetails] = await Promise.all([
                this.getProfessionalAverageRating(service.professional_id),
                this.getServiceDetails(service.service_id),
              ]);

              return {
                ...service,
                professional_average_rating: rating?.average_rating || null,
                professional_name: rating?.professional_name || 'Not Assigned',
                professional_phone: rating?.professional_phone || '',
                service_name: serviceDetails?.name || 'Unknown',
              };
            })
          );
          this.serviceHistory = servicesWithDetails;
        })
        .catch((error) => {
          console.error('Error fetching service history:', error);
        });
    },
    getProfessionalAverageRating(professionalId) {
      // if profesionnalId is null, return null
      if (!professionalId) {
        return null;
      }
      return axios.get(`http://127.0.0.1:5000/professional/${professionalId}/rating`, { headers: { 'Authorization': this.token } })
        .then(response => response.data)
        .catch(() => null);
    },
    getServiceDetails(serviceId) {
      if (!serviceId) return null;
      return axios
        .get(`http://127.0.0.1:5000/service/${serviceId}`, { headers: { Authorization: this.token } })
        .then((response) => response.data)
        .catch((error) => {
          console.error(`Error fetching details for service ID ${serviceId}:`, error);
          return null;
        });
    },

    searchServices() {
      // Check if the search text matches any category name
      const category = this.categories.find(cat => cat.name.toLowerCase() === this.searchText.toLowerCase());
      if (category) {
        // If a matching category is found, fetch services for that category
        this.showCategoryServices(category.id);
      } else {
        // Otherwise, perform a regular service search
        axios.post('http://127.0.0.1:5000/search_services', { query: this.searchText }, { headers: { 'Authorization': this.token } })
          .then(response => {
            this.searchResults = response.data;
          })
          .catch(error => {
            console.error('Error searching for services:', error);
            // Handle errors, e.g., show an error message to the user
          });
      }
    },
    bookService(service) {
      // Implement logic to book a service, such as making an API call to your backend

      axios.post('http://127.0.0.1:5000/book_service', { service_id: service.id }, { headers: { 'Authorization': this.token } })
        .then(response => {
          // Handle successful booking, e.g., show a success message to the user
          alert('Service booked successfully!');
          // Refresh the service history
          this.fetchServiceHistory();
        })
        .catch(error => {
          console.error('Error booking service:', error);
          // Handle errors, e.g., show an error message to the user
        });
    },
    cancelService(service) {
      // Implement logic to cancel a service, such as making an API call to your backend
      // Replace with your actual API call
      axios.post('http://127.0.0.1:5000/cancel_service_request', { request_id: service.id }, { headers: { 'Authorization': this.token } })
        .then(response => {
           // Update the status of the service in the serviceHistory array without removing it
          const canceledServiceIndex = this.serviceHistory.findIndex(s => s.id === service.id);
          if (canceledServiceIndex !== -1) {
          this.serviceHistory[canceledServiceIndex].status = 'Cancelled'; // Update the status
          }
        })
        .catch(error => {
          console.error('Error cancelling service:', error);
          // Handle errors, e.g., show an error message to the user
        });
    },
    rateService(service) {
      this.currentService = service;
      this.showRatingModal = true;
    },
    submitRating() {
      const payload = {
        customer_id: this.customer.id,
        professional_id: this.currentService.professional_id,
        rating: this.rating,
        review_text: this.reviewText,
      };

      axios.post('http://127.0.0.1:5000/rate_professional', payload, { headers: { 'Authorization': this.token } })
        .then(response => {
          alert('Rating submitted successfully!');
          this.showRatingModal = false;
          this.rating = null;
          this.reviewText = '';
          this.currentService = null;
        })
        .catch(error => {
          console.error('Error submitting rating:', error);
          alert('Failed to submit rating.');
        });
    },

    closeRatingModal() {
      this.showRatingModal = false;
      this.rating = null;
      this.reviewText = '';
      this.currentService = null;
    },

    prepareChartData() {
      if (!this.serviceHistory || this.serviceHistory.length === 0) return;

      const statusCounts = {
        Pending: 0,
        Completed: 0,
        Cancelled: 0,
      };

      this.serviceHistory.forEach((service) => {
        statusCounts[service.status] = (statusCounts[service.status] || 0) + 1;
      });

      this.serviceStatusData = {
        labels: Object.keys(statusCounts),
        datasets: [
          {
            label: 'Service Status',
            data: Object.values(statusCounts),
            backgroundColor: ['#ffc107', '#28a745', '#dc3545', '#007bff', '#17a2b8'],
          },
        ],
      };

      this.serviceHistoryData = {
        labels: this.serviceHistory.map((service) => service.service_name),
        datasets: [
          {
            label: 'Service Prices',
            data: this.serviceHistory.map((service) => service.price || 0),
            backgroundColor: '#007bff',
          },
        ],
      };

      this.renderCharts();
    },
    renderCharts() {
      // Destroy existing charts if they exist
      if (this.serviceStatusChart) {
        this.serviceStatusChart.destroy();
      }
      // if (this.serviceHistoryChart) {
      //   this.serviceHistoryChart.destroy();
      // }

      // Render service status chart
      const ctx1 = document.getElementById('serviceStatusChart').getContext('2d');
      this.serviceStatusChart = new Chart(ctx1, {
        type: 'pie',
        data: this.serviceStatusData,
        options: {
          responsive: true,
          plugins: {
            legend: {
              display: true,
              position: 'top',
            },
          },
        },
      });
    },
    editProfile() {
      // Copy current customer data into editableCustomer
      this.editableCustomer = { ...this.customer };
      this.showEditModal = true; // Show the edit modal
    },
    closeEditModal() {
      this.showEditModal = false; // Close the modal
    },
    submitProfileEdit() {
      // Send updated profile data to the backend
      axios.put('http://127.0.0.1:5000/customer/profile', this.editableCustomer, {
        headers: { 'Authorization': this.token }
      })
        .then(response => {
          // Update the local customer object with the new data
          this.customer = { ...this.editableCustomer };
          this.showEditModal = false; // Close the modal
          alert('Profile updated successfully!');
        })
        .catch(error => {
          console.error('Error updating profile:', error);
          alert('Failed to update profile.');
        });
    },
  }
};
</script>

<style scoped>
/* General Styling */
body {
  font-family: 'Arial', sans-serif;
  background-color: #f4f6f9;
  margin: 0;
  padding: 0;
  color: #333;
}

/* Dashboard Styling */
.dashboard {
  max-width: 1200px;
  margin: 20px auto;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
}

/* Header Styling */
.dashboard-header {
  border-bottom: 2px solid #007bff;
  padding-bottom: 15px;
  margin-bottom: 20px;
}

.dashboard-header h1 {
  font-size: 2.5rem;
  color: #333;
}

.dashboard-header h2 {
  font-size: 1.5rem;
  color: #666;
}

/* Profile Card Styling */
.profile-card {
  background: #ffffff;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
  padding: 20px;
}

.profile-card h2 {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 15px;
}

.profile-details ul {
  margin-bottom: 10px;
  font-size: 1rem;
  list-style-type: none;
  padding: 0;

}

.profile-details label {
  font-weight: bold;
  color: #555;
}

.profile-details span {
  font-weight: normal;
  color: #777;
}

.profile-card button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.profile-card button:hover {
  background-color: #0056b3;
  transform: scale(1.05);
}

/* Categories Card Styling */
.categories-card {
  background: #ffffff;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.categories-card h2 {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 15px;
}

.category-list {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
}

.btn-category {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.2rem;
  
  background-color: #0bc4d4;
  color: white;
  border: none;
  border-radius: 5px;
  /* padding: 10px 20px; */
  padding: 20px 40px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}


.btn-category:hover {
  background-color: #0a9cb7;
  transform: scale(1.05);
}

/* Search Section */
.search-section {
  background: #ffffff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.search-section h2 {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 15px;
}

.search-wrapper {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.search-wrapper input {
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
  font-size: 1rem;
  flex: 1;
  transition: border-color 0.3s ease;
}

.search-wrapper input:focus {
  border-color: #007bff;
  outline: none;
}

.search-wrapper button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.search-wrapper button:hover {
  background-color: #0056b3;
  transform: scale(1.05);
}

/* Search Results */
.search-results {
  margin-top: 20px;
}

.search-results h3 {
  font-size: 1.5rem;
  color: #333;
  margin-bottom: 15px;
}

.search-results .service-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border: 1px solid #e0e0e0;
  border-radius: 5px;
  margin-bottom: 10px;
  transition: box-shadow 0.3s ease;
}

.search-results .service-item:hover {
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.service-item h4 {
  font-size: 1.2rem;
  color: #333;
}

.service-price {
  font-size: 1rem;
  color: #007bff;
}

.search-results button {
  background-color: #28a745;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.search-results button:hover {
  background-color: #218838;
  transform: scale(1.05);
}

/* Service History Table */
.service-history {
  background: #ffffff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.service-history h2 {
  font-size: 1.8rem;
  color: #333;
  margin-bottom: 15px;
}

.service-history .service-table {
  width: 100%;
  border-collapse: collapse;
}

.service-history .service-table th,
.service-history .service-table td {
  padding: 10px;
  border: 1px solid #ccc;
  text-align: left;
}

.service-history .service-table th {
  background-color: #f1f1f1;
}

.service-history button {
  background-color: #dc3545;
  color: white;
  padding: 5px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.service-history button:hover {
  background-color: #c82333;
  transform: scale(1.05);
}

/* Modal Styling */
.rating-modal, .modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.rating-modal .modal-content, .modal .modal-content {
  background: white;
  border-radius: 8px;
  padding: 30px;
  max-width: 500px;
  width: 100%;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.rating-modal input, .modal input, .modal textarea {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 5px;
  border: 1px solid #ccc;
  transition: border-color 0.3s ease;
}

.rating-modal input:focus, .modal input:focus, .modal textarea:focus {
  border-color: #007bff;
  outline: none;
}

.rating-modal button, .modal button {
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.rating-modal button:hover, .modal button:hover {
  background-color: #0056b3;
  transform: scale(1.05);
}

/* Chart Styling */
.dashboard-summary .charts-container {
  width: 100%;
  height: 400px; /* Set a fixed height for the charts */
  gap: 30px;
}

.dashboard-summary canvas {
  width: 100%;
  height: 300px;
}

/* Floating Navbar styles */
.floating-navbar {
  position: fixed;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
  background-color: #f1f1f1;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.floating-navbar ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.floating-navbar li {
  margin-bottom: 10px;
}

.floating-navbar a {
  text-decoration: none;
  color: #007bff;
}

.floating-navbar a:hover {
  text-decoration: underline;
}

/* Button to toggle the navbar */
.toggle-navbar-btn {
  position: fixed;
  top: 10px;
  right: 10px;
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.toggle-navbar-btn:hover {
  background-color: #0056b3;
}
</style>