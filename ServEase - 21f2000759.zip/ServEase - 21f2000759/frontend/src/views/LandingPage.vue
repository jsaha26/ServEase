<template>
    <div class="landing-page">
      <div class="content-wrapper">
        <h2>Welcome to <span class="brand-name">ServeEase</span></h2>
        <p>Your one-stop solution for all household services.</p>
        <div class="button-group">
          <button @click="navigateTo('login')" class="btn btn-primary">Login</button>
          <button @click="navigateTo('registerProfessional')" class="btn btn-secondary">Register as a Professional</button>
          <button @click="navigateTo('registerCustomer')" class="btn btn-secondary">Register as a Customer</button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "LandingPage",
    mounted() {
      // Check if the user is already logged in
      const authToken = localStorage.getItem("authToken");
      if (authToken) {
        this.$router.push({ name: "dashboard" }); // Redirect to the dashboard
      }
    },
    methods: {
      navigateTo(route) {
        this.$router.push({ name: route });
      },
    },
  };
  </script>
  
  <style scoped>
  /* Landing page styling */
  .landing-page {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(to bottom right, #007bff, #6c63ff);
    color: white;
  }
  
  .content-wrapper {
    text-align: center;
    background: white;
    color: #333;
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 90%;
  }
  
  h2 {
    font-size: 2rem;
    margin-bottom: 10px;
  }
  
  .brand-name {
    color: #007bff;
    font-weight: bold;
  }
  
  p {
    margin-bottom: 20px;
    font-size: 1rem;
  }
  
  .button-group {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }
  
  .btn {
    padding: 12px 20px;
    font-size: 1rem;
    font-weight: bold;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  .btn-primary {
    background-color: #007bff;
    color: white;
  }
  
  .btn-primary:hover {
    background-color: #0056b3;
  }
  
  .btn-secondary {
    background-color: #6c63ff;
    color: white;
  }
  
  .btn-secondary:hover {
    background-color: #4d47cc;
  }

    .content-wrapper {
        animation: fadeIn 0.5s ease-in-out;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
  </style>
  