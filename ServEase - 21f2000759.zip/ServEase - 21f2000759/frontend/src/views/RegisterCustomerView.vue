<template>
    <div class="register-customer">
      <div class="form-container">
        <h3>Register as a Customer</h3>
        <form @submit.prevent="submit">
          <div class="input-group">
            <label for="email">Email</label>
            <input
              type="email"
              id="email"
              v-model="email"
              placeholder="Enter your email"
              required
            />
          </div>
  
          <div class="input-group">
            <label for="name">Full Name</label>
            <input
              type="text"
              id="name"
              v-model="name"
              placeholder="Enter your full name"
              required
            />
          </div>
  
          <div class="input-group">
            <label for="password">Password</label>
            <input
              type="password"
              id="password"
              v-model="password"
              placeholder="Enter your password"
              required
            />
          </div>
  
          <div class="input-group">
            <label for="address">Address</label>
            <input
              type="text"
              id="address"
              v-model="address"
              placeholder="Enter your address"
              required
            />
          </div>
  
          <div class="input-group">
            <label for="pincode">Pincode</label>
            <input
              type="text"
              id="pincode"
              v-model="pincode"
              placeholder="Enter your pincode"
              required
            />
          </div>
  
          <div class="input-group">
            <label for="phone_number">Phone Number</label>
            <input
              type="tel"
              id="phone_number"
              v-model="phone_number"
              placeholder="Enter your phone number"
              required
            />
          </div>
  
          <button type="submit" class="btn">Register</button>
          <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  import axios from "axios";
  
  export default {
    name: "RegisterCustomerView",
    data() {
      return {
        email: "",
        name: "",
        password: "",
        address: "",
        pincode: "",
        phone_number: "",
        errorMessage: "",
      };
    },
    methods: {
      async submit() {
        const customerData = {
          email: this.email,
          name: this.name,
          password: this.password,
          address: this.address,
          pincode: this.pincode,
          phone_number: this.phone_number,
        };
  
        try {
          const response = await axios.post(
            "http://localhost:5000/signup/customer",
            customerData
          );
  
          if (response.data.message === "Customer created successfully") {
            alert("Registration successful");
            this.$router.push({ name: "dashboard" });
          } else {
            this.errorMessage =
              response.data.message || "An error occurred during registration";
          }
        } catch (error) {
          console.error("Error during registration:", error);
          this.errorMessage = "An error occurred. Please try again later.";
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .register-customer {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: linear-gradient(to bottom right, #007bff, #6c63ff);
    padding: 20px;
  }
  
  .form-container {
    text-align: center;
    background: white;
    color: #333;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    max-width: 450px;
    width: 100%;
  }
  
h3 {
    margin-bottom: 20px;
    font-size: 1.8rem;
    font-weight: bold;
    color: #007bff;;
    letter-spacing: 0.5px;
}

  
.input-group {
    margin-bottom: 15px;
    text-align: left;
}

label {
    display: block;
    margin-bottom: 5px;
    font-size: 0.9rem;
    font-weight: 600;
    color: #555;
}

input 
{
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

select
{
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
    outline: none;
    box-sizing: border-box;
    transition: border-color 0.3s;
}

input:focus,
select:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

button {
    padding: 10px 20px;
    font-size: 1rem;
    border: none;
    background-color: #007bff;
    color: white;
    border-radius: 5px;
    cursor: pointer;
    /* width: 100%; */
    /* font-weight: 600; */
    /* text-transform: uppercase; */
    transition: background-color 0.3s;
}

button:hover {
    background-color: #0056b3;
}


.error-message {
    color: #e74c3c;
    margin-top: 15px;
    font-size: 0.9rem;
}

input[type="file"] {
    padding: 5px;
    font-size: 0.9rem;
}

input::placeholder {
    font-size: 0.9rem;
    color: #888;
}

/* Add subtle card animation */
.form-container {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>
