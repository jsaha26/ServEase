<template>
  <div class="dashboard">
    <h1>Professional Dashboard</h1>
    <h2>Welcome, {{ professional.name }}</h2>

    <section class="profile">
      <h2>Profile</h2>
      <ul>
        <li>
          <label for="name">Name:</label>
          <span>{{ professional.name }}</span>
        </li>
        <li>
          <label for="email">Email ID:</label>
          <span>{{ professional.email }}</span>
        </li>
        <li>
          <label for="phone">Phone Number:</label>
          <span>{{ professional.phone_number }}</span>
        </li>
        <li>
          <label for="address">Address:</label>
          <span>{{ professional.address }}, {{ professional.pincode }}</span>
        </li>
        <li>
          <label for="serviceType">Service Type:</label>
          <span>{{ professional.service_type }}</span>
        </li>
        <li>
          <label for="rating">Average Rating:</label>
          <span>{{ professional.average_rating }}</span>
        </li>
      </ul>
      <button class="btn btn-primary" @click="editProfile">Edit Profile</button>
    </section>

    <section class="service-requests">
      <div>
        <h3>Requests in Progress</h3>
        <table class="table" v-if="serviceRequestsInProgress.length > 0">
          <thead>
            <tr>
              <th>Customer Name</th>
              <th>Service</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in serviceRequestsInProgress" :key="request.id">

              <td><a href="#" @click.prevent="viewRequest(request)">{{ request.customer_name }}</a></td>
              <td>{{ request.service_name }}</td>
              <td>
                <button @click="completeService(request)">Complete</button>
              </td>
            </tr>
          </tbody>
        </table>
        <p v-else>No requests in progress.</p>
      </div>

      <div>
        <h3>Pending Requests</h3>
        <div>
          <input type="text" v-model="searchQuery" placeholder="Search services by name..."
            @input="filterPendingRequests" />
          <button @click="filterPendingRequests">Search</button>
        </div>

        <table class="table" v-if="filteredServiceRequestsPending.length > 0">
          <thead>
            <tr>
              <th>Customer Name</th>
              <th>Service</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in filteredServiceRequestsPending" :key="request.id">
              <td><a href="#" @click.prevent="viewRequest(request)">{{ request.customer_name }}</a></td>
              <td>{{ request.service_name }}</td>
              <td>
                <button @click="acceptRequest(request)">Accept</button>
                <button @click="rejectRequest(request)">Reject</button>
              </td>
            </tr>
          </tbody>
        </table>
        <p v-else>No pending requests found.</p>
      </div>

      <div>
        <h3>Request History</h3>
        <table v-if="serviceRequestsHistory.length > 0">
          <thead>
            <tr>
              <th>Customer Name</th>
              <th>Service</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in serviceRequestsHistory" :key="request.id">

              <td>{{ request.customer_name }}</td>
              <td>{{ request.service_name }}</td>
              <td>{{ request.status }}</td>
            </tr>
          </tbody>
        </table>
        <p v-else>No completed requests.</p>
      </div>
    </section>

    <!-- Summary Charts Section -->
    <section class="dashboard-summary">
      <h2>Dashboard Summary</h2>
      <div class="charts-container">
        <div class="chart-card">
          <canvas id="requestsStatusChart"></canvas>
        </div>
        <div class="chart-card">
          <canvas id="requestsHistoryChart"></canvas>
        </div>
      </div>
    </section>

    <!-- Service Request Details Modal -->
    <div class="modal" v-if="selectedRequest">
      <div class="modal-content">
        <span class="close" @click="selectedRequest = null">&times;</span>
        <h2>Service Request Details</h2>
        <p><strong>Customer Name:</strong> {{ selectedRequest.customer_name }}</p>

        <p><strong>Customer Address:</strong> {{ selectedRequest.customer_address }}, {{
          selectedRequest.customer_pincode }}</p>
        <!-- <p><strong>Customer Email:</strong> {{ selectedRequest.customer_email }}</p> -->
        <p><strong>Customer Phone Number:</strong> {{ selectedRequest.customer_phone_number }}</p>
        <p><strong>Service:</strong> {{ selectedRequest.service_name }}</p>
        <p><strong>Service Description:</strong> {{ selectedRequest.service_description }}</p>
        <p><strong>Service Price:</strong> ₹ {{ selectedRequest.service_price }}</p>
        <p><strong>Status:</strong> {{ selectedRequest.status }}</p>
        <p><strong>Request Date:</strong> {{ selectedRequest.request_date }}</p>
      </div>
    </div>


    <div v-if="showEditModal" class="modal">
      <div class="modal-content">
        <h2>Edit Profile</h2>
        <form @submit.prevent="submitProfileEdit">
          <label for="name">Name:</label>
          <input v-model="editableProfessional.name" type="text" id="name" required />


          <label for="phone_number">Phone Number:</label>
          <input v-model="editableProfessional.phone_number" type="tel" id="phone_number" required />

          <label for="address">Address:</label>
          <input v-model="editableProfessional.address" type="text" id="address" required />

          <label for="pincode">Pincode:</label>
          <input v-model="editableProfessional.pincode" type="text" id="pincode" required />

          <label for="experience">Experience:</label>
          <input v-model="editableProfessional.experience" type="text" id="experience" required />

          <div class="modal-actions">
            <button class="btn btn-primary" type="submit">Save</button>
            <button class="btn btn-secondary" type="button" @click="closeEditModal">Cancel</button>
          </div>
        </form>
      </div>



    </div>
  </div>
</template>

<script>
import axios from 'axios';
import Chart from 'chart.js/auto';

export default {
  data() {
    return {
      professional: {},
      editableProfessional: {},
      showEditModal: false,
      serviceRequests: [],
      searchQuery: '',
      filteredServiceRequestsPending: [],
      selectedRequest: null,
      token: null,
      role: null,
      requestsStatusChart: null // Store the chart instance
    };
  },
  created() {
    this.token = localStorage.getItem('authToken');
    this.role = localStorage.getItem('role');
    if (!this.token) {
      this.$router.push('/login');
    }
    if (this.role !== 'professional') {
      alert('You are not authorized to access this page.');
      this.$router.push('/login');
    }
    

    this.fetchProfessionalData();
    this.fetchServiceRequests();
    this.fetchServiceRequestsHistory();
  },
  computed: {
    serviceRequestsPending() {
      return this.serviceRequests.filter(request => request.status === 'Pending');
    },
    serviceRequestsInProgress() {
      return this.serviceRequests.filter(request => request.status === 'Accepted');
    },
    serviceRequestsHistory() {
      return this.serviceRequests.filter(request => request.status === 'Completed' || request.status === 'Rejected' || request.status === 'Cancelled');
    }
  },
  methods: {
    filterPendingRequests() {
      const query = this.searchQuery.toLowerCase();
      this.filteredServiceRequestsPending = this.serviceRequestsPending.filter(request =>
        request.service_name.toLowerCase().includes(query)
      );
    },
    editProfile() {
      // Copy current customer data into editableCustomer
      this.editableProfessional = { ...this.professional };
      this.showEditModal = true; // Show the edit modal
    },
    closeEditModal() {
      this.showEditModal = false; // Close the edit modal
    },
    submitProfileEdit() {
      axios.put('http://127.0.0.1:5000/professional/profile', this.editableProfessional, {
        headers: { 'Authorization': this.token }
      })
        .then(response => {
          // Update the local professional object with the new data
          this.professional = { ...this.editableProfessional };
          this.showEditModal = false; // Close the modal
          alert('Profile updated successfully!');
        })
        .catch(error => {
          console.error('Error updating profile:', error);
          alert('Failed to update profile.');
        });
    },


  viewRequest(request) {
    this.selectedRequest = request;
  },
  fetchProfessionalData() {
    axios.get('http://127.0.0.1:5000/customer/profile', { headers: { 'Authorization': this.token } })
      .then(response => {
        this.professional = response.data;

        // Check if the professional is approved
        if (this.professional.status === null) {
          alert('Your account is not approved yet. Please wait for approval.');
          this.$router.push('/login');
        }
        if (this.professional.status === false) {
          alert('Your account is rejected. Please contact the admin for more details.');
          this.$router.push('/login');
        }
        if (this.professional.active === false) {
          alert('Your account is deactivated/blocked. Please contact the admin for more details.');
          this.$router.push('/login');
        }
        

      })
      .catch(error => {
        console.error('Error fetching professional data:', error);
      });
  },
  fetchServiceRequests() {
    axios.get('http://127.0.0.1:5000/professional_service_requests', { headers: { 'Authorization': this.token } })
      .then(response => {
        this.serviceRequests = response.data;
        this.filteredServiceRequestsPending = this.serviceRequestsPending;
        this.fetchServiceRequestsHistory();
        this.prepareChartData();

      })
      .catch(error => {
        console.error('Error fetching service requests:', error);
        alert('Failed to load service requests. Please try again later.');
      });
  },
  acceptRequest(request) {
    axios.post('http://127.0.0.1:5000/accept_service_request', { request_id: request.id }, { headers: { 'Authorization': this.token } })
      .then(response => {
        this.fetchServiceRequests();
      })
      .catch(error => {
        console.error('Error accepting service request:', error);
      });
  },
  rejectRequest(request) {
    axios.post('http://127.0.0.1:5000/reject_service_request', { request_id: request.id }, { headers: { 'Authorization': this.token } })
      .then(response => {
        request.status = 'Rejected';
      })
      .catch(error => {
        console.error('Error rejecting service request:', error);
      });
  },
  completeService(request) {
    axios.post('http://127.0.0.1:5000/complete_service_request', { request_id: request.id }, { headers: { 'Authorization': this.token } })
      .then(response => {
        request.status = 'Completed';
        this.fetchServiceRequestsHistory();
      })
      .catch(error => {
        console.error('Error completing service request:', error);
        alert('Failed to mark the service as completed. Please try again later.');
      });
  },
  fetchServiceRequestsHistory() {
    axios.get('http://127.0.0.1:5000/professional_service_requests_history', { headers: { 'Authorization': this.token } })
      .then(response => {
        this.serviceRequests = this.serviceRequests.concat(response.data);
        this.prepareChartData();
      })
      .catch(error => {
        console.error('Error fetching completed service requests:', error);
      });
  },
  prepareChartData() {
    const statusCounts = {
      // Accepted: 0,
      // Pending: 0,
      Completed: 0,
      Rejected: 0,
      // Cancelled: 0
    };

    // Use the serviceRequestsHistory instead of serviceRequests
    this.serviceRequestsHistory.forEach(request => {
      statusCounts[request.status] = (statusCounts[request.status] || 0) + 1;
    });

    // Prepare data for the pie chart
    this.requestsStatusData = {
      labels: Object.keys(statusCounts),
      datasets: [{
        label: 'Service Requests History Status',
        data: Object.values(statusCounts),
        backgroundColor: ['#007bff', '#ffc107', '#dc3545', '#dc3545', '#6c757d'], // Colors for each status
        // hoverBackgroundColor: ['#0056b3', '#e0a800', '#c82333', '#c82333', '#5a6268'] // Hover colors
      }]
    };

    this.renderRequestsStatusChart(); // Ensure chart is rendered with updated data
  },
  renderRequestsStatusChart() {
    if (this.requestsStatusChart) {
      this.requestsStatusChart.destroy();
    }

    const ctx = document.getElementById('requestsStatusChart').getContext('2d');
    this.requestsStatusChart = new Chart(ctx, {
      type: 'doughnut', // Change chart type to 'doughnut'
      data: this.requestsStatusData,
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top'
          },
          tooltip: {
            callbacks: {
              label: function (context) {
                const label = context.label || '';
                const value = context.raw || 0;
                return `${label}: ${value}`;
              }
            }
          }
        }
      }
    });
  },

},
mounted() {
  this.renderRequestsStatusChart();
}
};
</script>

<style scoped>
body {
  font-family: 'Arial', sans-serif;
  background-color: #f4f6f9;
  margin: 0;
  padding: 0;
  color: #333;
}

/* General dashboard styling */
.dashboard {
  font-family: Arial, sans-serif;
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

h1,
h2,
h3 {
  color: #333;
  margin-bottom: 10px;
}

h1 {
  font-size: 2rem;
  text-align: center;
}

h2,
h3 {
  font-size: 1.5rem;
  border-bottom: 2px solid #007bff;
  padding-bottom: 5px;
}

/* Profile section styling */
.profile {
  margin-bottom: 30px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.profile ul {
  list-style: none;
  padding: 0;
}

.profile li {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #ddd;
}

.profile li:last-child {
  border-bottom: none;
}

.profile label {
  font-weight: bold;
  color: #555;
}

.profile button {
  display: inline-block;
  margin-top: 15px;
  padding: 10px 20px;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.profile button:hover {
  background-color: #0056b3;
}

/* Service requests section */
.service-requests div {
  margin-bottom: 20px;
}

.service-requests input {
  padding: 10px;
  width: calc(100% - 120px);
  border: 1px solid #ccc;
  border-radius: 4px;
}

.service-requests button {
  background-color: #28a745;
  color: #fff;
  padding: 10px 15px;
  margin-left: 10px;
}

.service-requests button.reject {
  background-color: #dc3545;
}

.service-requests button.complete {
  background-color: #ffc107;
}

.service-requests table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

.service-requests th,
.service-requests td {
  padding: 10px;
  text-align: left;
  border: 1px solid #ddd;
}

.service-requests th {
  background-color: #007bff;
  color: #fff;
}

/* Charts section */
.dashboard-summary {
  margin-top: 30px;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.charts-container {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
}

.chart-card {
  flex: 1;
  min-width: 300px;
  margin: 10px;
  padding: 10px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Buttons */
button {
  transition: background-color 0.3s ease;
}

button:active {
  transform: scale(0.98);
}


/* Table Styling */
.table {
  width: auto;
  /* Dynamic width based on content */
  max-width: 100%;
  /* Prevent overflow */
  border-collapse: collapse;
  margin: 0 auto 20px;
  /* Center the table and add bottom margin */
}

/* Table Header and Data Styling */
.table th,
.table td {
  border: 1px solid #ddd;
  padding: 8px;
  /* Compact padding for better spacing */
  text-align: center;
  /* Align text to the left for better readability */
  white-space: nowrap;
  /* Prevent columns from stretching unnecessarily */
}

/* Table Header Styling */
.table th {
  background-color: #f4f4f4;
  color: #333;
  font-weight: bold;
}

/* Alternating Row Colors */
.table tr:nth-child(even) {
  background-color: #f9f9f9;
}

.table tr:hover {
  background-color: #f1f1f1;
}

/* Responsive Table Styling */
@media (max-width: 768px) {
  .table {
    width: 100%;
    /* Adapts to smaller screens */
  }

  .table th,
  .table td {
    white-space: normal;
    /* Allow wrapping for smaller screens */
  }
}


.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  border-radius: 10px;
  width: 60%;
  max-width: 800px;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  position: relative;
}

.modal-content h2 {
  color: #4caf50;
}

.close {
  position: absolute;
  top: 10px;
  right: 15px;
  font-size: 1.5rem;
  cursor: pointer;
  color: #888;
}

.close:hover {
  color: #4caf50;
}
</style>
