<template>
    <div class = "login-form">
        <div class = "form-container">
            <h3>Login to Your Account</h3>
            <div class = "input-group">
                <input type = "text" placeholder = "Email" v-model = "this.name" required/>
            </div>
            <div class = "input-group">
                <input type = "password" placeholder = "Password" v-model = "this.desc" required/>
            </div>
            <button @click = "submit" class = "btn">Login</button>
        </div>
    </div>
</template>
<script>
import axios from 'axios';

export default {
    name: 'CreateCategory',
    data() {
        return {
            name: null,
            desc: null
        }
    },
    methods: {
        submit() {
            // Check if both fields are filled
            if (!this.name || !this.desc) {
                alert('Please fill in all fields');
                return;
            }
            console.log('submit')
            axios
            .post('http://localhost:5000/signin',
                {
                    'email': this.name,
                    'password': this.desc
                }
            )
            .then(response => {
                console.log("correct response", response)
                if (response.data.status === "success in loggin") {
                    localStorage.setItem('authToken', response.data.authToken);
                    localStorage.setItem('role', response.data.role);

                    this.name = null;
                    this.desc = null;

                    switch (response.data.role) {
                        case 'admin':
                            this.$router.push({ name: 'dashboard' });
                            break;
                        case 'professional':
                            this.$router.push({ name: 'professionalDashboard' });
                            break;
                        case 'customer':
                            this.$router.push({ name: 'customerDashboard' });
                            break;
                        default:
                            alert('Unexpected role. Please contact support.');
                    }
                }

            })
            .catch(error => {
                console.log("error response", error)
            })
        }
    }
}
</script>


<style scoped>
/* General styles for the login form */
.login-form {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(to bottom right, #007bff, #6c63ff);
  color: white;
}

.form-container {
  background: white;
  color: #333;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
  text-align: center;
  width: 350px;
}

h3 {
  margin-bottom: 20px;
  color: #007bff;
}

.input-group {
  margin-bottom: 15px;
}

input {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 1rem;
  outline: none;
  box-sizing: border-box;
  transition: border-color 0.3s;
}

input:focus {
  border-color: #007bff;
}

.btn {
  padding: 10px 20px;
  font-size: 1rem;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
  transition: background-color 0.3s;
}

.btn:hover {
  background-color: #0056b3;
}

.form-container {
    animation: fadeIn 0.5s ease-in-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}


</style>