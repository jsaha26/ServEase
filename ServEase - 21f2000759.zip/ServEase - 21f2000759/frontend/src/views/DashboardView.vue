<template>
  <div class="dashboard">


    <!-- Button to toggle the navbar visibility -->
    <button class="toggle-navbar-btn" @click="toggleNavbar">
      Toggle Navbar
    </button>

    <div v-if="isNavbarVisible" class="floating-navbar">
      <ul>
        <ul><a href="#" @click="scrollToSection('search')">Search</a></ul>
        <ul><a href="#" @click="scrollToSection('users')">Users</a></ul>
        <ul><a href="#" @click="scrollToSection('services')">Services</a></ul>
        <ul><a href="#" @click="scrollToSection('requests')">Requests</a></ul>
        <ul><a href="#" @click="scrollToSection('summary')">Summary</a></ul>
      </ul>
    </div>

    <!-- Main Heading for the Admin Dashboard -->
    <h1>Admin's Dashboard</h1>

    <!-- Search Input -->
    <section id="search">

      <div class="search-container">
        <input type="text" v-model="searchQuery" placeholder="Search..." class="search-box" />
      </div>
    </section>


    <!-- Section for Managing Users -->

    <!-- Service Professionals Table -->
    <section id="users" class="user-management">
      <h2>Service Professionals</h2>
      <table class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Service Type</th>
            <th>Experience</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="professional in filteredProfessionals" :key="professional.id">
            <td>{{ professional.id }}</td>
            <td>
              <a href="#" @click.prevent="showDetails(professional)">
                {{ professional.name }}
              </a>
            </td>
            <td>{{ professional.service_type }}</td>
            <td>{{ professional.experience }}</td>
            <td>
              <span v-if="professional.active === false">Blocked</span>
              <span v-else-if="professional.approved === true">Approved</span>
              <span v-else-if="professional.approved === false">Rejected</span>
              <span v-else>Pending</span>
            </td>
            <td>
              <button class="unblock" v-if="professional.active === false"
                @click="unblockUser(professional.id)">Unblock</button>
              <button class="block" v-else-if="professional.approved === true"
                @click="blockUser(professional.id)">Block</button>
              <button class="block" v-else-if="professional.approved === false"
                @click="blockUser(professional.id)">Block</button>
              <div v-else>
                <button class="approve" @click="approveProfessional(professional.id)">Approve</button>
                <button class="reject" @click="rejectProfessional(professional.id)">Reject</button>
                <button class="block" @click="blockUser(professional.id)">Block</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- Customers Table -->
    <section class="user-management">
      <h2>Customers</h2>
      <table class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="customer in filteredCustomers" :key="customer.id">
            <td>{{ customer.id }}</td>
            <td>
              <a href="#" @click.prevent="showCustomerDetails(customer)">
                {{ customer.name }}
              </a>
            </td>
            <td>{{ customer.email }}</td>
            <td>
              <span v-if="customer.blocked">Blocked</span>
              <span v-else>Active</span>
            </td>
            <td>
              <button class="unblock" v-if="customer.blocked" @click="unblockUser(customer.id)">Unblock</button>
              <button class="block" v-else @click="blockUser(customer.id)">Block</button>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- Professional Details Modal -->
    <div v-if="selectedProfessional" class="modal">
      <div class="modal-content">
        <!-- Close button for the modal -->
        <span class="close" @click="selectedProfessional = null">&times;</span>
        <h2>{{ selectedProfessional.name }}'s Details</h2>
        <!-- Display professional details -->
        <p><strong>Service Type:</strong> {{ selectedProfessional.service_type }}</p>
        <p><strong>Rating:</strong> {{ selectedProfessional.average_rating }}</p>
        <p><strong>Experience:</strong> {{ selectedProfessional.experience }} years</p>
        <p><strong>Email:</strong> {{ selectedProfessional.email }}</p>
        <p><strong>Address:</strong> {{ selectedProfessional.address }}, {{ selectedProfessional.pincode }}</p>
        <p><strong>Phone Number:</strong> {{ selectedProfessional.phone_number }}</p>

        <!-- Provide link to view professional's document -->
        <p><strong>Document:</strong>
          <a :href="`http://localhost:5000/static/${selectedProfessional.document_path.split('/').pop()}`"
            target="_blank">View Document</a>
        </p>

        <!-- Display status of professional (Blocked, Approved, Rejected, Pending) with actions -->
        <span v-if="selectedProfessional.active == false" style="color: orange; font-weight: bold;"> - Blocked <br><br>
          <button class="unblock" @click="unblockUser(selectedProfessional.id)">Unblock</button>
        </span>

        <span v-else-if="selectedProfessional.approved === true" style="color: green; font-weight: bold;"> - Approved
          <br><br>
          <button class="block" @click="blockUser(selectedProfessional.id)">Block</button>
        </span>

        <span v-else-if="selectedProfessional.approved === false" style="color: red; font-weight: bold;"> - Rejected
          <br><br>
          <button class="block" @click="blockUser(selectedProfessional.id)">Block</button>
        </span>
        <span v-else style="font-weight: bold;"> - Pending <br><br>
          <br>
          <button class="approve" @click="approveProfessional(selectedProfessional.id)">Approve</button>
          <button class="reject" @click="rejectProfessional(selectedProfessional.id)">Reject</button>
          <button class="block" @click="blockUser(selectedProfessional.id)">Block</button>
        </span>

      </div>
    </div>

    <!-- Customer Details Modal -->
    <div v-if="selectedCustomer" class="modal">
      <div class="modal-content">
        <!-- Close button for the modal -->
        <span class="close" @click="selectedCustomer = null">&times;</span>
        <h2>{{ selectedCustomer.name }}'s Details</h2>
        <!-- Display customer details -->
        <p><strong>Email:</strong> {{ selectedCustomer.email }}</p>
        <p><strong>Phone Number:</strong> {{ selectedCustomer.phone_number }}</p>
        <p><strong>Address:</strong> {{ selectedCustomer.address }}</p>

        <!-- Blocked status with the option to unblock -->
        <span v-if="selectedCustomer.blocked"> - Blocked
          <button class="unblock" @click="unblockUser(selectedCustomer.id)">Unblock</button>
        </span>
        <span v-else>
          <button class="block" @click="blockUser(selectedCustomer.id)">Block</button>
        </span>
      </div>
    </div>

    <!-- Section for Managing Services -->
    <section id="services">
      <h2>Services</h2>


      <!-- Create Add Category Button -->
      <button class="add_category" @click="showCreateCategoryForm = true">Add Category</button>

      <!-- Show Create Category Form -->
      <create-category v-if="showCreateCategoryForm" @close="showCreateCategoryForm = false" />

      <div v-for="(services, category) in categorizedServices" :key="category" class="service-category">
        <h3>{{ category }}</h3>
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Price</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="service in filteredServicesByCategory(services)" :key="service.id">
              <td>{{ service.id }}</td>
              <td>
                <a href="#" @click.prevent="showServiceDetails(service)">
                  {{ service.name }}
                </a>
              </td>
              <td>{{ service.price }}</td>
              <td>
                <button class="edit" @click="editService(service)">Edit</button>
                <button class="delete" @click="deleteService(service.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>

        <button class="add-service" @click="addService(category)">Add Service</button>
      </div>
    </section>
  </div>

  <!-- Service Details Modal -->
  <div v-if="selectedService" class="modal">
    <div class="modal-content">
      <span class="close" @click="selectedService = null">&times;</span>
      <h2>{{ selectedService.name }}'s Details</h2>
      <p><strong>Category:</strong> {{ selectedService.category_name }}</p>
      <p><strong>Description:</strong> {{ selectedService.description }}</p>
      <p><strong>Price:</strong> {{ selectedService.price }}</p>


      <button class="edit" @click="editService(selectedService)">Edit Service</button>
      <button class="delete" @click="deleteService(selectedService.id)">Delete Service</button>
    </div>
  </div>
  <!-- </section> -->

  <!-- Edit Service Modal -->
  <div v-if="editMode" class="modal">
    <h2>Edit Service</h2>
    <input v-model="selectedService.name" placeholder="Service Name" />
    <input v-model="selectedService.description" placeholder="Description" />
    <input v-model="selectedService.price" placeholder="Price" type="number" />

    <button class="save" @click="saveService">Save Changes</button>
    <button class="cancel" @click="editMode = false">Cancel</button>

  </div>

  <section id="requests">
    <h2>Service Requests</h2>
    <button @click="triggerExport">Export Closed Requests as CSV</button>
    <table class="service-requests">
      <thead>
        <tr>
          <th>ID</th>
          <th>Customer Name</th>
          <th>Service</th>
          <th>Assigned Professional</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="request in serviceRequests" :key="request.id">
          <td>{{ request.id }}</td>
          <td>{{ request.customer_name }}</td>
          <td>{{ request.service_name }}</td>
          <td>{{ request.assigned_professional || 'Not Assigned' }}</td>
          <td>{{ request.status }}</td>
          <td>
            <button class="view" @click="viewRequestDetails(request)">View</button>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="selectedRequest" class="modal">
      <div class="modal-content">
        <span class="close" @click="selectedRequest = null">&times;</span>
        <h2>Service Request Details</h2>
        <p><strong>Customer Name:</strong> {{ selectedRequest.customer_name }}</p>
        <p><strong>Service:</strong> {{ selectedRequest.service_name }}</p>
        <p><strong>Status:</strong> {{ selectedRequest.status }}</p>
        <p><strong>Description:</strong> {{ selectedRequest.description }}</p>
        <p><strong>Created At:</strong> {{ selectedRequest.request_date }}</p>
        <p><strong>Customer's Review:</strong> {{ selectedRequest.review || 'No review yet' }}</p>
      </div>
    </div>
  </section>

  <!-- Summary Section with Charts -->
  <section id="summary" class="dashboard-summary">
    <h2>Dashboard Summary</h2>
    <div class="charts-container">
      <div class="chart-card">
        <canvas id="usersChart"></canvas>
      </div>
      <div class="chart-card">
        <canvas id="servicesChart"></canvas>
      </div>
    </div>
  </section>

  <!-- Logout Button -->
  <br>
  <button @click="logout">Logout</button>

</template>

<script>
import router from '@/router';
import axios from 'axios';
import createCategory from '@/components/createCategory.vue'; // Import the CreateCategory component
import CreateService from '@/components/createService.vue';
import Chart from 'chart.js/auto';

export default {
  name: 'Dashboard',
  components: {
    createCategory // Register the CreateCategory component
  },
  data() {
    return {
      professionals: [], // List of professionals to display
      customers: [], // List of customers to display
      services: [], // List of services available
      categories: [], // List of categories available
      serviceRequests: [], // List of service requests
      selectedProfessional: null, // Selected professional for viewing details
      selectedCustomer: null, // Selected customer for viewing details
      showCreateCategoryForm: false, // Flag to show/hide the CreateCategory form
      selectedService: null, // Selected service for viewing details
      editMode: false, // Flag to indicate if we're in edit mode,
      selectedRequest: null, // Selected service request for viewing details
      searchQuery: '', // Search query for filtering users
      token: null, // Authentication token,
      isNavbarVisible: true
    };
  },

  created() {
    // Retrieve the token from localStorage
    this.token = localStorage.getItem('authToken');
    this.role = localStorage.getItem('role');

    // Redirect if the token is not valid
    if (!this.token || this.role !== 'admin') {
      router.push('/login');
    }
  },
  computed: {
    // Categorize services, including empty categories
    categorizedServices() {
      const categorized = this.categories.reduce((acc, category) => {
        acc[category.name] = []; // Initialize each category with an empty array
        return acc;
      }, {});

      // Add services to their respective categories
      this.services.forEach(service => {
        const categoryName = service.category_name || 'Uncategorized';
        if (!categorized[categoryName]) {
          categorized[categoryName] = [];
        }
        categorized[categoryName].push(service);
      });

      return categorized;
    },
    // Filtered professionals based on search query
    filteredProfessionals() {
      return this.professionals.filter(professional =>
        professional.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    },

    // Filtered customers based on search query
    filteredCustomers() {
      return this.customers.filter(customer =>
        customer.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    },

  },

  methods: {


    toggleNavbar() {
      this.isNavbarVisible = !this.isNavbarVisible;
    },
    scrollToSection(sectionId) {
      const section = document.getElementById(sectionId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    },
    // Filter services by category based on search query
    filteredServicesByCategory(services) {
      return services.filter(service =>
        service.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    },
    async fetchDashboardData() {
      try {
        const [professionalsResponse, customersResponse, servicesResponse, categoriesResponse] = await Promise.all([
          axios.get('http://127.0.0.1:5000/professionals', {
            headers: {
              'Authorization': this.token
            }
          }),
          axios.get('http://127.0.0.1:5000/api/customers', {
            headers: {
              'Authorization': this.token
            }
          }),
          axios.get('http://127.0.0.1:5000/services', {
            headers: {
              'Authorization': this.token
            }
          }),
          axios.get('http://127.0.0.1:5000/all_categories', {
            headers: {
              'Authorization': this.token
            }
          })
        ]);

        this.professionals = professionalsResponse.data;
        this.customers = customersResponse.data;
        this.services = servicesResponse.data;
        this.categories = categoriesResponse.data; // Store categories

        // Create charts
        this.createSummaryCharts();



      } catch (error) {
        console.error('Failed to load data:', error);
      }
    },

    createSummaryCharts() {
      const usersChartCtx = document.getElementById('usersChart').getContext('2d');
      const servicesChartCtx = document.getElementById('servicesChart').getContext('2d');

      // Chart for users (Professionals and Customers)
      new Chart(usersChartCtx, {
        type: 'bar',
        data: {
          labels: ['Professionals', 'Customers'],
          datasets: [{
            label: 'Count',
            data: [this.professionals.length, this.customers.length],
            backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(153, 102, 255, 0.2)'],
            borderColor: ['rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });

      // Chart for services
      new Chart(servicesChartCtx, {
        type: 'pie',
        data: {
          labels: this.categories.map(category => category.name), // Assuming categories have a name property
          datasets: [{
            label: 'Services',
            data: this.categories.map(category => this.services.filter(service => service.category_name === category.name).length),
            backgroundColor: this.categories.map(() => `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.2)`),
            borderColor: this.categories.map(() => `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 1)`),
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top',
            },
            title: {
              display: true,
              text: 'Services by Category'
            }
          }
        }
      });
    },

    // Approve a professional user
    async approveProfessional(id) {
      try {
        await axios.post('http://127.0.0.1:5000/approve/professional', { professional_id: id }, { headers: { 'Authorization': this.token } });
        alert('Professional approved');

        // Update local data for approval
        const professional = this.professionals.find(p => p.id === id);
        if (professional) {
          professional.approved = true;
          professional.active = true;
        }
        if (this.selectedProfessional && this.selectedProfessional.id === id) {
          this.selectedProfessional.approved = true;
          this.selectedProfessional.active = true;
        }
      } catch (error) {
        console.error('Error approving professional:', error);
      }
    },

    // Reject a professional user
    async rejectProfessional(id) {
      try {
        await axios.post('http://127.0.0.1:5000/reject/professional', { professional_id: id }, { headers: { 'Authorization': this.token } });
        alert('Professional rejected');

        const professional = this.professionals.find(p => p.id === id);
        if (professional) {
          professional.approved = false;
        }
        if (this.selectedProfessional && this.selectedProfessional.id === id) {
          this.selectedProfessional.approved = false;
        }
      } catch (error) {
        console.error('Error rejecting professional:', error);
      }
    },

    // Block a user (either customer or professional)
    async blockUser(id) {
      try {
        await axios.post('http://127.0.0.1:5000/block', { user_id: id }, { headers: { 'Authorization': this.token } });
        alert('User blocked');

        // Update local data for blocking
        const user = this.professionals.find(p => p.id === id) || this.customers.find(c => c.id === id);
        if (user) {
          user.active = false;
          user.blocked = true; // Add this line to set blocked status for customers
        }
        if (this.selectedProfessional && this.selectedProfessional.id === id) {
          this.selectedProfessional.active = false;
        }
        if (this.selectedCustomer && this.selectedCustomer.id === id) {
          this.selectedCustomer.blocked = true;
        }
      } catch (error) {
        console.error('Error blocking user:', error);
      }
    },

    // Unblock a user
    async unblockUser(id) {
      try {
        await axios.post('http://127.0.0.1:5000/unblock', { user_id: id }, { headers: { 'Authorization': this.token } });
        alert('User unblocked');

        // Update local data for unblocking
        const user = this.professionals.find(p => p.id === id) || this.customers.find(c => c.id === id);
        if (user) {
          user.active = true;
          user.blocked = false; // Add this line to set blocked status for customers
        }
        if (this.selectedProfessional && this.selectedProfessional.id === id) {
          this.selectedProfessional.active = true;
        }
        if (this.selectedCustomer && this.selectedCustomer.id === id) {
          this.selectedCustomer.blocked = false;
        }
      } catch (error) {
        console.error('Error unblocking user:', error);
      }
    },

    // Show detailed information for a selected professional
    showDetails(professional) {
      this.selectedProfessional = professional;
    },

    // Show detailed information for a selected customer
    showCustomerDetails(customer) {
      this.selectedCustomer = customer;
    },
    showServiceDetails(service) {
      this.selectedService = service;
    },
    addService(category) {
      const category_id = category; // Assuming each category has an id property
      this.$router.push({ name: 'create-service', params: { category_id } });
    },


    fetchServices() {
      axios.get('http://127.0.0.1:5000/services', {
        headers: {
          'Authorization': this.token
        }
      })
        .then(response => {
          this.services = response.data;
        })
        .catch(error => console.error(error));
    },
    // Edit a service
    editService(service) {
      this.selectedService = { ...service };
      this.editMode = true; // Display the edit form/modal
    },
    // Save changes to service
    saveService() {
      axios.put(`http://127.0.0.1:5000/services/${this.selectedService.id}`,
        {
          price: this.selectedService.price,
          description: this.selectedService.description,
          name: this.selectedService.name
        }
        , {
          headers: {
            'Authorization': this.token
          }
        })
        .then(() => {
          this.fetchServices(); // Refresh the list
          this.editMode = false;
          this.selectedService = null;
        })
        .catch(error => console.error(error));
    },
    // Delete a service
    deleteService(serviceId) {
      if (confirm("Are you sure you want to delete this service?")) {
        axios.delete(`http://127.0.0.1:5000/services/${serviceId}`, { headers: { 'Authorization': this.token } })
          .then(() => {
            this.fetchServices(); // Refresh the list
            this.selectedService = null; // Close the modal if open
          })
          .catch(error => console.error(error));
      }
    },

    async fetchServiceRequests() {
      try {
        // Fetching all required data in parallel
        const [serviceRequestsResponse, servicesResponse, customersResponse, professionalsResponse] = await Promise.all([
          axios.get('http://127.0.0.1:5000/all_service_requests', { headers: { 'Authorization': this.token } }),
          axios.get('http://127.0.0.1:5000/services', { headers: { 'Authorization': this.token } }),
          axios.get('http://127.0.0.1:5000/api/customers', { headers: { 'Authorization': this.token } }),
          axios.get('http://127.0.0.1:5000/professionals', { headers: { 'Authorization': this.token } })
        ]);

        this.services = servicesResponse.data;
        this.customers = customersResponse.data;
        this.professionals = professionalsResponse.data;

        // Merging customer and service details into service requests
        this.serviceRequests = serviceRequestsResponse.data.map(request => {
          const customer = this.customers.find(c => c.id === request.customer_id);
          const service = this.services.find(s => s.id === request.service_id);
          const professional = this.professionals.find(p => p.id === request.professional_id);

          return {
            ...request,
            customer_name: customer ? customer.name : 'Unknown Customer',
            service_name: service ? service.name : 'Unknown Service',
            assigned_professional: professional ? professional.name : 'Not Assigned'

          };
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    },
    viewRequestDetails(request) {
      this.selectedRequest = request;
    },

    async triggerExport() {
      try {
        const response = await axios.post('http://127.0.0.1:5000/trigger-csv-export');
        const taskId = response.data.task_id;
        alert(response.data.message);

        // Poll for completion
        this.checkExportStatus(taskId);
      } catch (error) {
        console.error('Error triggering export:', error);
      }
    },
    async checkExportStatus(taskId) {
      const interval = setInterval(async () => {
        try {
          const statusResponse = await axios.get(`http://127.0.0.1:5000/check-export-status/${taskId}`, {
            responseType: 'blob', // Expect a file download
          });

          if (statusResponse.headers['content-disposition']) {
            // File is ready, stop polling
            clearInterval(interval);

            // Download the file
            const url = window.URL.createObjectURL(new Blob([statusResponse.data]));
            const link = document.createElement('a');
            link.href = url;

            // Extract the filename from headers if needed
            const contentDisposition = statusResponse.headers['content-disposition'];
            const filename = contentDisposition
              ? contentDisposition.split('filename=')[1].replace(/"/g, '')
              : 'export.csv';

            link.setAttribute('download', filename);
            document.body.appendChild(link);
            link.click();
            link.remove();
          }
        } catch (error) {
          console.error('Error checking export status:', error);
          clearInterval(interval);
        }
      }, 3000); // Poll every 3 seconds
    },


    // Logout the admin
    logout() {
      localStorage.removeItem('authToken');

      router.push('/login');
    }
  },

  mounted() {
    // Fetch data when the component is mounted
    this.fetchDashboardData();
    this.fetchServiceRequests();
  }
};
</script>

<style scoped>
.dashboard {
  font-family: 'Arial', sans-serif;
  padding: 20px;
  background-color: #f4f4f4;
}

h1,
h2,
h3 {
  color: #333;
}

.blocked {
  color: red;
}

.action-button {
  margin-left: 10px;
  padding: 5px 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

.action-button:hover {
  background-color: #0056b3;
}

.delete {
  background-color: #dc3545;
}

.delete:hover {
  background-color: #c82333;
}

.service-category {
  margin-bottom: 20px;
}

.service-link {
  color: #007bff;
  text-decoration: none;
}

.service-link:hover {
  text-decoration: underline;
}

.add-button {
  margin-top: 10px;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #28a745;
  color: white;
  cursor: pointer;
}

.add-button:hover {
  background-color: #218838;
}



.logout-button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: #dc3545;
  color: white;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #c82333;
}





.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer
}

/* Search Container Styles */
.search-container {
  margin-bottom: 20px;
}

.search-box {
  padding: 10px;
  width: 100%;
  max-width: 400px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

/* User List Styles */
.user-list {
  margin-bottom: 30px;
}

.user-link {
  color: #007bff;
  text-decoration: none;
}

.user-link:hover {
  text-decoration: underline;
}

/* Status Styles */
.status {
  margin-left: 10px;
}

.blocked {
  color: red;
}

/* Button Styles */
.action-button {
  margin-left: 10px;
  padding: 5px 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

.action-button:hover {
  background-color: #0056b3;
}

.delete {
  background-color: #dc3545;
}

.delete:hover {
  background-color: #c82333;
}

/* Service Category Styles */
.service-category {
  margin-bottom: 20px;
}

.service-link {
  color: #007bff;
  text-decoration: none;
}

.service-link:hover {
  text-decoration: underline;
}

.add-button {
  margin-top: 10px;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #28a745;
  color: white;
  cursor: pointer;
}

.add-button:hover {
  background-color: #218838;
}



/* Logout Button Styles */
.logout-button {
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  background-color: #dc3545;
  color: white;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #c82333;
}

/* Modal Styles */




.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

/* Chart Styles */
.charts-container {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.chart-card {
  flex: 1;
  margin: 0 10px;
  background-color: white;
  border-radius: 5px;
  padding: 20px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

#usersChart,
#servicesChart {
  width: 100% !important;
  /* Ensures the chart takes the full width */
  height: 300px !important;
  /* Set a height for the chart */
}

/* Responsive Styles */
@media (max-width: 768px) {
  .charts-container {
    flex-direction: column;
  }

  .chart-card {
    margin: 10px 0;
  }
}

.dashboard {
  font-family: 'Arial', sans-serif;
  padding: 20px;
  color: #333;
  background-color: #f9f9f9;
  min-height: 100vh;
}

h1 {
  font-size: 2.5rem;
  color: #4caf50;
  text-align: center;
  margin-bottom: 20px;
}

h2,
h3 {
  color: #555;
  border-bottom: 2px solid #4caf50;
  padding-bottom: 5px;
  margin-bottom: 10px;
}

.search-container {
  margin: 20px 0;
  text-align: center;
}

.service-category {
  background: white;
  padding: 15px;
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.service-category ul {
  list-style: none;
  padding: 0;
}

.service-category li {
  padding: 10px;
  border-bottom: 1px solid #eee;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.service-category li:last-child {
  border-bottom: none;
}

button:hover {
  background-color: #4caf50;
  color: white;
}

button:focus {
  outline: none;
}

button[disabled] {
  cursor: not-allowed;
  background-color: #ccc;
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: white;
  border-radius: 10px;
  width: 60%;
  max-width: 800px;
  padding: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  position: relative;
}

.modal-content h2 {
  color: #4caf50;
}

.close {
  position: absolute;
  top: 10px;
  right: 15px;
  font-size: 1.5rem;
  cursor: pointer;
  color: #888;
}

.close:hover {
  color: #4caf50;
}

.dashboard-summary {
  margin-top: 30px;
  padding: 15px;
  background: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.charts-container {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  margin-top: 20px;
}

.chart-card {
  flex: 1;
  max-width: 45%;
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 10px;
  background-color: #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin: 10px;
}

.service-requests {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

.service-requests th,
.service-requests td {
  padding: 10px;
  text-align: left;
  border: 1px solid #ddd;
}

.service-requests th {
  background-color: #4caf50;
  color: white;
}

.service-requests tbody tr:hover {
  background-color: #e7e7e7;
}
</style>

<style scoped>
/* User Management Section */
.user-management {
  margin-bottom: 40px;
}

.user-list {
  margin-top: 20px;
}

.user-item {
  background-color: #fff;
  padding: 15px;
  margin: 10px 0;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.user-link {
  font-weight: bold;
  color: #333;
  text-decoration: none;
}

.user-actions {
  margin-top: 10px;
}

button {
  padding: 5px 10px;
  margin: 0 5px;
  border-radius: 5px;
  border: none;
  background-color: #007BFF;
  color: white;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Service Management Section */
.service-management {
  margin-top: 40px;
}

.service-category {
  margin-top: 20px;
}

.service-item {
  background-color: #fff;
  padding: 15px;
  margin: 10px 0;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}


/* Service Requests Section */
.service-requests {
  margin-top: 40px;
}

.service-requests-table {
  width: 100%;
  border-collapse: collapse;
}

.service-requests-table th,
.service-requests-table td {
  padding: 10px;
  text-align: left;
  border: 1px solid #ccc;
}

.service-requests-table th {
  background-color: #f4f4f4;
}



.modal-content {
  background-color: #fff;
  padding: 20px;
  margin: 10% auto;
  width: 80%;
  max-width: 600px;
  border-radius: 10px;
}

/* Dashboard Summary Section */
.dashboard-summary {
  margin-top: 40px;
}

.charts-container {
  display: flex;
  justify-content: space-between;
}

.chart-card {
  width: 48%;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Table Styling */
.table {
  width: auto;
  /* Dynamic width based on content */
  max-width: 100%;
  /* Prevent overflow */
  border-collapse: collapse;
  margin: 0 auto 20px;
  /* Center the table and add bottom margin */
}

/* Table Header and Data Styling */
.table th,
.table td {
  border: 1px solid #ddd;
  padding: 8px;
  /* Compact padding for better spacing */
  text-align: center;
  /* Align text to the left for better readability */
  white-space: nowrap;
  /* Prevent columns from stretching unnecessarily */
}

/* Table Header Styling */
.table th {
  background-color: #f4f4f4;
  color: #333;
  font-weight: bold;
}

/* Alternating Row Colors */
.table tr:nth-child(even) {
  background-color: #f9f9f9;
}

.table tr:hover {
  background-color: #f1f1f1;
}

/* Responsive Table Styling */
@media (max-width: 768px) {
  .table {
    width: 100%;
    /* Adapts to smaller screens */
  }

  .table th,
  .table td {
    white-space: normal;
    /* Allow wrapping for smaller screens */
  }
}


.add-service-btn {
  margin-top: 10px;
  padding: 10px 20px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
}

.add-service-btn:hover {
  background-color: #218838;
}

.logout-btn {
  display: block;
  margin: 20px auto;
  padding: 10px 20px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 5px;
  text-align: center;
}

.logout-btn:hover {
  background-color: #c82333;
}

button.block {
  background-color: #fd7e14;
  color: white;
}

button.block:hover {
  background-color: #e76f00;
}

button.unblock {
  background-color: #28a745;
  color: white;
}

button.unblock:hover {
  background-color: #218838;
}

button.approve {
  background-color: #007bff;
  color: white;
}

button.approve:hover {
  background-color: #0056b3;
}

button.reject {
  background-color: #dc3545;
  color: white;
}

button.reject:hover {
  background-color: #c82333;
}

button.edit {
  background-color: #007bff;
  color: white;
}

button.edit:hover {
  background-color: #0056b3;
}

button.delete {
  background-color: #dc3545;
  color: white;
}

button.delete:hover {
  background-color: #c82333;
}

button.add-service {
  background-color: #28a745;
  color: white;
}

button.add-service:hover {
  background-color: #218838;
}

button.save {
  background-color: #007bff;
  color: white;
}

button.save:hover {
  background-color: #0056b3;
}

button.cancel {
  background-color: #dc3545;
  color: white;
}

button.cancel:hover {
  background-color: #c82333;
}

button.view {
  background-color: #007bff;
  color: white;
}

button.view:hover {
  background-color: #0056b3;
}

button.add_category {
  background-color: #28a745;
  color: white;
}



/* Floating Navbar styles */
.floating-navbar {
  position: fixed;
  top: 50%;
  right: 0;
  transform: translateY(-50%);
  background-color: #f1f1f1;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.floating-navbar ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.floating-navbar li {
  margin-bottom: 10px;
}

.floating-navbar a {
  text-decoration: none;
  color: #007bff;
}

.floating-navbar a:hover {
  text-decoration: underline;
}

/* Button to toggle the navbar */
.toggle-navbar-btn {
  position: fixed;
  top: 10px;
  right: 10px;
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.toggle-navbar-btn:hover {
  background-color: #0056b3;
}
</style>
