<template>
  <div class="about">
    <h1>ServEase</h1>
    <div>
      <p>ServEase is a robust and scalable solution that effectively bridges the gap between customers and service professionals while offering powerful management tools for admins. The app leverages a well-structured database, modern frameworks, and advanced features like background tasks and caching to ensure an optimized user experience.</p>
      <p>It is a multi-user platform designed to offer home servicing solutions. It includes three primary user roles: Admin, Service Professionals, and Customers. The app provides a comprehensive solution for managing services, professionals, and customer interactions.</p>
    </div>
  </div>
</template>

<style scoped>
div.about {
  display: flex;
  flex-direction: column;
  justify-content: left;
  align-items: center;
  margin-top: 50px;
}
</style>
