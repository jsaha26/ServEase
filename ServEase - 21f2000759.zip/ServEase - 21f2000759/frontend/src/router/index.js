import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'Landing',
    component: () => import(/* webpackChunkName: "landing" */ '../views/LandingPage.vue')
  },
  {
    path: '/home',
    name: 'home',
    component: HomeView
  },
  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../views/LoginView.vue')
  },
  {
    path: '/registerProfessional',
    name: 'registerProfessional',
    component: () => import(/* webpackChunkName: "registerProfessional" */ '../views/RegisterProfessionalView.vue')
  },
  {
    path: '/registerCustomer',
    name: 'registerCustomer',
    component: () => import(/* webpackChunkName: "registerCustomer" */ '../views/RegisterCustomerView.vue')
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: () => import(/* webpackChunkName: "dashboard" */ '@/views/DashboardView.vue')
  },
  {
    path: '/professionalDashboard',
    name: 'professionalDashboard',
    component: () => import(/* webpackChunkName: "professionalDashboard" */ '@/views/ProfessionalDashboardView.vue')
  },
  {
    path: '/customerDashboard',
    name: 'customerDashboard',
    component: () => import(/* webpackChunkName: "customerDashboard" */ '@/views/CustomerDashboardView.vue')

  },
  {
    path: '/createCategory',
    name: 'createCategory',
    component: () => import(/* webpackChunkName: "createCategory" */ '@/components/createCategory.vue')
  },
  // {
  //   path: '/services/new',
  //   name: 'create-service',
  //   component: () => import(/* webpackChunkName: "create-service" */ '@/components/createService.vue')
  // },
  {
    path: '/add-service/:category_id',
    name: 'create-service',
    component: () => import(/* webpackChunkName: "create-service" */ '@/components/createService.vue'),
    props: true
  }
  


]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
